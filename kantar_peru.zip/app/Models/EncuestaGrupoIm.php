<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EncuestaGrupoIm extends Model
{
    protected $table= "encuesta_grupo_im";
}
