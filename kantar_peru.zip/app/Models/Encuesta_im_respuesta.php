<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Encuesta_im_respuesta extends Model
{
    protected $table="encuesta_im_respuesta";
}
