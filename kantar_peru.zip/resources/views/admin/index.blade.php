@extends('admin.layouts.app')
@section('content')
<h1>PANEL DE RESUMEN</h1>
@endsection