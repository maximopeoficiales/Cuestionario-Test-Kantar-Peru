<?php $__env->startSection('content'); ?> 
<style>
.efecto:hover .imagen {-webkit-transform:scale(1.3);transform:scale(1.3);transition-duration: 500ms;}
.efecto {overflow:hidden;}
@media (max-width: 768px) {
    .mifuente {
        font-size: 30px;
    }
}
</style>
<div class="container">
<a href="<?php echo e(route('encuestas')); ?>" class="btn btn-primary float-right animated bounce "><i class="fas fa-arrow-left mr-2"></i>Regresar</a>
    <br>
    <h1 class="text-center display-3 my-4 animated bounce mifuente"><?php echo e($texto->texto); ?></h1>
    <div class="card-columns animated bounce">
        <?php $__currentLoopData = $encuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card" >
            <a href="#" data-toggle="modal" data-target="#exampleModal_<?php echo e($e->id_encuesta); ?>">
                <div class="efecto">
                    <img class="card-img-top imagen" src="<?php echo e($e->imagen); ?>" alt="Card image cap" style="width: 100%; height: 300px;">

                </div>
            </a>
            <div class="card-body animated rubberBand">
                <?php $__currentLoopData = $e->informacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h5 class="card-title text-center"><?php echo e($i->titulo); ?></h5>
                <p class="card-text text-justify"><?php echo e($e->texto); ?></p>
                        
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> 
    <?php $__currentLoopData = $encuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $e->informacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="exampleModal_<?php echo e($e->id_encuesta); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
            <div class="modal-dialog" role="document">
                <div class="modal-content" style="border-radius: 5%;">
                    <div class="modal-header">
                    <h5 class="modal-title h2" id="exampleModalLabel" style="margin: 0 auto;"><?php echo e($i->titulo); ?></h5>
                    </div>
                    <div class="modal-body">
                        <div class="text-center">
                            <img src="<?php echo e($e->imagen); ?>" alt="encuesta img" class="my-4" style="width: 100%; height: 300px; border-radius: 10%">
                            <p>Valido Hasta: <b><?php echo e($i->fecha_vencimiento); ?></b></p>
                            <p>Total de Registros: <b><?php echo e($i->cuenta); ?></b></p>
                            <div class=" d-flex justify-content-center">
                                <a href="<?php echo e(route('encuestas.show',[$id_encuesta_grupo_im,$e->id_encuesta])); ?>" class="btn btn-success mr-2"><i class="fa fa-sign-in mr-2" aria-hidden="true"></i>Ingresar</a>
                                <button type="button" class="btn btn-danger ml-2" data-dismiss="modal"><i class="fa fa-times mr-2" aria-hidden="true"></i>Cancelar</button>
                            </div>
                        </div>
                    </div> 
                </div>
            </div>
        </div>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>