<?php $__env->startSection('content'); ?>
<h1 class="text-center my-2">Lista de Encuestas</h1>
<div class="card mb-4">
    <div class="card-header"><i class="fas fa-table mr-1"></i>Lista de Encuestas</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Encuesta</th>
                        <th>Fecha de Creacion</th>
                        <th>Fecha de Vencimiento</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Encuesta</th>
                        <th>Fecha de Creacion</th>
                        <th>Fecha de Vencimiento</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $encuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $en): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($en->titulo); ?></td>
                        <td><?php echo e($en->fecha_creacion); ?></td>
                        <td><?php echo e($en->fecha_vencimiento); ?></td>
                        <td><?php echo e($en->estado); ?></td>
                        <td>
                            <a href="" class="btn btn-primary"><i class="far fa-eye"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                        
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
    <script>
    $(document).ready(function() {
    $('#dataTable').DataTable();
    } );
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>